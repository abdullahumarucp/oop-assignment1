#include "MyChar.h"

MyChar::MyChar()
{
	cout << "default  constructor called" << endl;
}
MyChar::MyChar(char a)
{
	cout << "default parameterized constructor called" << endl;
	Num = a;
}
void MyChar::setChar(char a)
{
	Num = a;
}

char MyChar::getChar()
{
	return Num;
}

void MyChar::upperChar()
{
	if (Num <= 'Z'&& Num >= 'A')
	{
		Num = Num + 32;
		cout << Num <<" | ";
	}	
}
void MyChar::lowerChar()
{
	if (Num <= 'z'&& Num >= 'a')
	{
		Num = Num - 32;
		cout << Num << " | ";
	}
}

