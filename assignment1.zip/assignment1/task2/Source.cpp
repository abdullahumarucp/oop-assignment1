#include"MyChar.h"

int main()
{
	MyChar n, n1, n2, n3('m');
	char m[3] = {};
	for (int i = 0; i < 3; i++)
	{
		cout << "Enter the " << i + 1 << " number : ";
		cin >> m[i];
	}
	char temp = 0;

	n.setChar(m[0]);
	n.upperChar();
	n.lowerChar();
	n1.setChar(m[1]);
	n1.upperChar();
	n1.lowerChar();
	n2.setChar(m[2]);
	n2.upperChar();
	n2.lowerChar();
	cout << endl;
	cout << "perameterized constructor" << endl;
	n3.upperChar();
	n3.lowerChar();
	cout << endl;

	for (int i = 0; i < 3; i++)
	{
		for (int j = 0; j<3; j++)
		{
			if (m[i] < m[j])
			{
				temp = m[i];
				m[i] = m[j];
				m[j] = temp;
			}
		}
	}
	cout << "the sorted array is : " << endl;
	for (int i = 0; i < 3; i++)
	{
		cout << m[i] << " ";
	}
	system("pause");
	return 0;
}

