#include "MyNum.h"

MyNum::MyNum()
{
cout << "default constructor called" << endl;
}
MyNum::MyNum(double a)
{
	cout << "default parameterized constructor called" << endl;
	Num = a;
}
void MyNum::setNum(double a)
{
	Num = a;
}

double MyNum::getNum()
{
	return Num;
}

void MyNum::negativeNum()
{
	if (Num < 0)
	{
		double b = Num - (Num * 2);
		cout << "the number is : " << b << endl;
	}
	else
	{
		cout << "the number you enter is postive" << endl;
	}
}
void MyNum::positiveNum()
{
	if (Num > 0)
	{
		double b = Num + (Num * -2);
		cout << "the number is : " << b << endl;
	}
	else
	{
		cout << "the number you enter is negtive" << endl;
	}
}

