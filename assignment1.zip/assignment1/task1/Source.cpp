#include"MyNum.h"

int main()
{
	cout << endl;
	MyNum n, n1, n2;
	MyNum n3(9);
	double m[3] = {};
	for (int i = 0; i < 3; i++)
	{
		cout << "Enter the "<<i+1<< " number : ";
		cin >> m[i];
	}
	int temp = 0;
	for (int i = 0; i < 3; i++)
	{
		for (int j = 0; j<3; j++)
		{
			if (m[i] < m[j])
			{
				temp = m[i];
				m[i] = m[j];
				m[j] = temp;
			}
		}
	}
	
	n.setNum(m[0]);
	n.negativeNum();
	n.positiveNum();
	n1.setNum(m[1]);
	n1.negativeNum();
	n1.positiveNum();
	n2.setNum(m[2]);
	n2.negativeNum();
	n2.positiveNum();
	n3.negativeNum();
	n3.positiveNum();
	cout << "the sorted array is : " << endl;
	for (int i = 0; i < 3; i++)
	{
		cout << m[i] << " ";
	}
	system("pause");
	return 0;
}

